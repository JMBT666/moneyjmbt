        
<!DOCTYPE html>
<html id="locale" lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title class="company"></title>

	  <!-- Bootstrap core CSS     -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" />

    <!--  Paper Dashboard core CSS    -->
    <link href="<?php echo e(asset('css/paper-dashboard.css')); ?>" rel="stylesheet"/>
	
	<!--  Datatables    -->
	<link href="<?php echo e(asset('plugin/datatables/css/dataTables.bootstrap.css')); ?>" rel="stylesheet"/>

    <!--  Fonts and icons     -->
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="<?php echo e(asset('css/themify-icons.css')); ?>"  rel="stylesheet">
	<link href="<?php echo e(asset('plugin/datatables/css/buttons.dataTables.min.css')); ?>"  rel="stylesheet">
	<link href="<?php echo e(asset('plugin/datatables/css/buttons.bootstrap.min.css')); ?>"  rel="stylesheet">
	<link href="<?php echo e(asset('css/datepicker.css')); ?>" rel="stylesheet">
	<link href="<?php echo e(asset('plugin/morris/morris.css')); ?>"  rel="stylesheet">
	<link href="<?php echo e(asset('plugin/fullcalendar/fullcalendar.css')); ?>"  rel="stylesheet">
	<!-- Scripts -->

    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/fullcalendar/lib/moment.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/fullcalendar/fullcalendar.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/datatables/js/jquery.dataTables.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/datatables/js/dataTables.bootstrap.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/datatables/js/dataTables.buttons.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/datatables/js/buttons.html5.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/datatables/js/buttons.print.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/datatables/js/buttons.bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/datatables/js/pdfmake.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/datatables/js/vfs_fonts.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/chartjs/Chart.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/morris/morris.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/jscolor/jscolor.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/morris/raphael-min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/chartjs/Chart.PieceLabel.js')); ?>"></script>




</head>
<body>
 
        
<div class="sidebar">	
<div class=" sidebar-wrapper">
    <div class="logo">
                <img class="logoimg" src="" style="width:200px"/>
        </a>
    </div>
    <ul class="nav">
			
            <li class="<?php echo e(Request::is( 'home') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'home')); ?>" >
                    <i class="ti-panel"></i>
					<p><?php echo trans('lang.dashboard');?></p>
                </a>
            </li>
			<?php if(Auth::check()): ?>
				<?php if(Auth::user()->isrole('2')): ?>
			 <li class="<?php echo e(Request::is( 'transaction') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'transaction')); ?>" >
                    <i class="ti-direction-alt"></i>
					<p><?php echo trans('lang.transactions');?></p>
                </a>
            </li>
				<?php endif; ?>
			<?php endif; ?>
			<?php if(Auth::check()): ?>
				<?php if(Auth::user()->isrole('3')): ?>
			 <li class="<?php echo e(Request::is( 'income') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'income')); ?>" >
                    <i class="ti-stats-up"></i>
					<p><?php echo trans('lang.income');?></p>
                </a>
            </li>
				<?php endif; ?>
			<?php endif; ?>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('19')): ?>
             <li class="<?php echo e(Request::is( 'upcomingincome') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'upcomingincome')); ?>" >
                    <i class="ti-angle-double-up"></i>
                    <p><?php echo trans('lang.upcomingincome');?></p>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
			<?php if(Auth::check()): ?>
				<?php if(Auth::user()->isrole('4')): ?>
			 <li class="<?php echo e(Request::is( 'expense') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'expense')); ?>" >
                    <i class="ti-stats-down"></i>
					<p><?php echo trans('lang.expense');?></p>
                </a>
            </li>
				<?php endif; ?>
			<?php endif; ?>
             <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('20')): ?>
             <li class="<?php echo e(Request::is( 'upcomingexpense') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'upcomingexpense')); ?>" >
                    <i class="ti-angle-double-down"></i>
                    <p><?php echo trans('lang.upcomingexpense');?></p>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
			<?php if(Auth::check()): ?>
				<?php if(Auth::user()->isrole('5')): ?>
			 <li class="<?php echo e(Request::is( 'account') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'account')); ?>" >
                    <i class="ti-wallet"></i>
					<p><?php echo trans('lang.accounts');?></p>
                </a>
            </li>
				<?php endif; ?>
			<?php endif; ?>
			<?php if(Auth::check()): ?>
				<?php if(Auth::user()->isrole('6')): ?>
			 <li class="<?php echo e(Request::is( 'budget') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'budget')); ?>" >
                    <i class="ti-package"></i>
					<p><?php echo trans('lang.track_budget');?> </p>
                </a>
            </li>
				<?php endif; ?>
			<?php endif; ?>
			<?php if(Auth::check()): ?>
				<?php if(Auth::user()->isrole('7')): ?>
			 <li class="<?php echo e(Request::is( 'goals') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'goals')); ?>" >
                    <i class="ti-cup"></i>
					<p><?php echo trans('lang.set_goals');?></p>
                </a>
            </li>
				<?php endif; ?>
			<?php endif; ?>
			<?php if(Auth::check()): ?>
				<?php if(Auth::user()->isrole('8')): ?>
			<li class="<?php echo e(Request::is( 'calendar') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'calendar')); ?>" >
                    <i class="ti-calendar"></i>
					<p><?php echo trans('lang.calendar');?></p>
                </a>
            </li>
				<?php endif; ?>
			<?php endif; ?>
			
			 <li class="<?php echo e(Request::is( 'reports/allreports') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'reports/allreports')); ?>" >
                    <i class="ti-pie-chart"></i>
					<p><?php echo trans('lang.report_menu');?></p>
                </a>
            </li>
				
			 <li>
                 <a data-toggle="collapse" href="#category" class="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? '' : 'collapsed'); ?>" aria-expanded="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? 'true' : 'false'); ?>">
                    <i class="ti-flag-alt"></i>
                    <p><?php echo trans('lang.category');?><b class="caret"></b></p>
                </a>
				<div class="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? 'collapse in' : 'collapse'); ?>" id="category" aria-expanded="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? 'true' : 'false'); ?>" style="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? '' : 'height: 0px;'); ?>">
                    <ul class="nav">
						<?php if(Auth::check()): ?>
							<?php if(Auth::user()->isrole('9')): ?>
                          <li class="<?php echo e(Request::is( 'incomecategory') ? 'active' : ''); ?>">
                            <a href="<?php echo e(URL::to( 'incomecategory')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.income_category');?></span>
                            </a>
                        </li>
							<?php endif; ?>
						<?php endif; ?>
						<?php if(Auth::check()): ?>
							<?php if(Auth::user()->isrole('10')): ?>
						<li class="<?php echo e(Request::is( 'expensecategory') ? 'active' : ''); ?>">
                           <a href="<?php echo e(URL::to( 'expensecategory')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.expense_category');?></span>
                            </a>
                        </li>
							<?php endif; ?>
						<?php endif; ?>
                    </ul>
                </div>
            </li>


			 <li>
                 <a data-toggle="collapse" href="#settings" class="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? '' : 'collapsed'); ?>" aria-expanded="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? 'true' : 'false'); ?>">
                    <i class="ti-settings"></i>
                    <p><?php echo trans('lang.setting_menu');?><b class="caret"></b></p>
                </a>
				<div class="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? 'collapse in' : 'collapse'); ?>" id="settings" aria-expanded="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? 'true' : 'false'); ?>" style="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? '' : 'height: 0px;'); ?>">
                    <ul class="nav">
                        <li class="<?php echo e(Request::is( 'settings/profile') ? 'active' : ''); ?>">
                            <a href="<?php echo e(URL::to( 'settings/profile')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.profile_settings');?></span>
                            </a>
                        </li>
						<?php if(Auth::check()): ?>
							<?php if(Auth::user()->isrole('17')): ?>
						<li class="<?php echo e(Request::is( 'settings/allusers') ? 'active' : ''); ?>">
                            <a href="<?php echo e(URL::to( 'settings/allusers')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.user_role');?></span>
                            </a>
                        </li>
							<?php endif; ?>
						<?php endif; ?>
						<?php if(Auth::check()): ?>
							<?php if(Auth::user()->isrole('18')): ?>
                           <li class="<?php echo e(Request::is( 'settings/application') ? 'active' : ''); ?>">
                            <a href="<?php echo e(URL::to( 'settings/application')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.application_setting');?></span>
                            </a>
                        </li>
							<?php endif; ?>
						<?php endif; ?>	
                    </ul>
                </div>
    </ul>
</div>
</div>
<div class="main-panel">
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
           <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
            <a class="navbar-brand" href="#"><p class="company"></p></a>
        </div>

        <!--responsive-->
        <div class="collapse" id="myNavbar">
        <ul class="nav">
            
            <li  class="<?php echo e(Request::is( 'home') ? 'active' : ''); ?>">
                <a  href="<?php echo e(URL::to( 'home')); ?>" >
                    <p><?php echo trans('lang.dashboard');?></p>
                </a>
            </li>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('2')): ?>
             <li class="<?php echo e(Request::is( 'transaction') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'transaction')); ?>" >
                    <p><?php echo trans('lang.transactions');?></p>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('3')): ?>
             <li class="<?php echo e(Request::is( 'income') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'income')); ?>" >
                    <p><?php echo trans('lang.income');?></p>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('19')): ?>
             <li class="<?php echo e(Request::is( 'upcomingincome') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'upcomingincome')); ?>" >
                    <p><?php echo trans('lang.upcomingincome');?></p>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('4')): ?>
             <li class="<?php echo e(Request::is( 'expense') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'expense')); ?>" >
                    <p><?php echo trans('lang.expense');?></p>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
             <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('20')): ?>
             <li class="<?php echo e(Request::is( 'upcomingexpense') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'upcomingexpense')); ?>" >
                    <p><?php echo trans('lang.upcomingexpense');?></p>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('5')): ?>
             <li class="<?php echo e(Request::is( 'account') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'account')); ?>" >
                    <p><?php echo trans('lang.accounts');?></p>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('6')): ?>
             <li class="<?php echo e(Request::is( 'budget') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'budget')); ?>" >
                    <p><?php echo trans('lang.track_budget');?> </p>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('7')): ?>
             <li class="<?php echo e(Request::is( 'goals') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'goals')); ?>" >
                    <p><?php echo trans('lang.set_goals');?></p>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('8')): ?>
            <li class="<?php echo e(Request::is( 'calendar') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'calendar')); ?>" >
                    <p><?php echo trans('lang.calendar');?></p>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
            
             <li class="<?php echo e(Request::is( 'reports/allreports') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'reports/allreports')); ?>" >
                    <p><?php echo trans('lang.report_menu');?></p>
                </a>
            </li>
                
             <li>
                 <a data-toggle="collapse" href="#categorys" class="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? '' : 'collapsed'); ?>" aria-expanded="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? 'true' : 'false'); ?>">
                    <p><?php echo trans('lang.category');?><b class="caret"></b></p>
                </a>
                <div class="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? 'collapse in' : 'collapse'); ?>" id="categorys" aria-expanded="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? 'true' : 'false'); ?>" style="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? '' : 'height: 0px;'); ?>">
                    <ul class="nav">
                        <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->isrole('9')): ?>
                          <li class="<?php echo e(Request::is( 'incomecategory') ? 'active' : ''); ?>">
                            <a href="<?php echo e(URL::to( 'incomecategory')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.income_category');?></span>
                            </a>
                        </li>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->isrole('10')): ?>
                        <li class="<?php echo e(Request::is( 'expensecategory') ? 'active' : ''); ?>">
                           <a href="<?php echo e(URL::to( 'expensecategory')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.expense_category');?></span>
                            </a>
                        </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </li>


             <li>
                 <a data-toggle="collapse" href="#settingss" class="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? '' : 'collapsed'); ?>" aria-expanded="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? 'true' : 'false'); ?>">
                    <p><?php echo trans('lang.setting_menu');?><b class="caret"></b></p>
                </a>
                <div class="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? 'collapse in' : 'collapse'); ?>" id="settingss" aria-expanded="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? 'true' : 'false'); ?>" style="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? '' : 'height: 0px;'); ?>">
                    <ul class="nav">
                        <li class="<?php echo e(Request::is( 'settings/profile') ? 'active' : ''); ?>">
                            <a href="<?php echo e(URL::to( 'settings/profile')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.profile_settings');?></span>
                            </a>
                        </li>
                        <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->isrole('17')): ?>
                        <li class="<?php echo e(Request::is( 'settings/allusers') ? 'active' : ''); ?>">
                            <a href="<?php echo e(URL::to( 'settings/allusers')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.user_role');?></span>
                            </a>
                        </li>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->isrole('18')): ?>
                           <li class="<?php echo e(Request::is( 'settings/application') ? 'active' : ''); ?>">
                            <a href="<?php echo e(URL::to( 'settings/application')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.application_setting');?></span>
                            </a>
                        </li>
                            <?php endif; ?>
                        <?php endif; ?>  
                    </ul>
                </div>
            </ul>
    </div>
        <!--end responsive-->

        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
               <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#"><?php echo trans('lang.new');?>
                    <i class="ti-new"></i>
                    <b class="caret"></b>
                    <ul class="dropdown-menu">
                      <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->isrole('2')): ?>
                         <li class="<?php echo e(Request::is( 'transaction') ? 'active' : ''); ?>">
                             <a href="<?php echo e(URL::to( 'transaction')); ?>" >
                                <p><?php echo trans('lang.transactions');?></p>
                            </a>
                        </li>
                            <?php endif; ?>
                        <?php endif; ?>
                       <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->isrole('11')): ?>
                         <li class="<?php echo e(Request::is( 'reports/allreports') ? 'active' : ''); ?>">
                             <a href="<?php echo e(URL::to( 'reports/income')); ?>" >
                                <p><?php echo trans('lang.income_reports');?></p>
                            </a>
                        </li>
                            <?php endif; ?>
                        <?php endif; ?>
                         <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->isrole('12')): ?>
                         <li class="<?php echo e(Request::is( 'reports/allreports') ? 'active' : ''); ?>">
                             <a href="<?php echo e(URL::to( 'reports/expense')); ?>" >
                                <p><?php echo trans('lang.expense_reports');?></p>
                            </a>
                        </li>
                            <?php endif; ?>
                        <?php endif; ?>
                         <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->isrole('16')): ?>
                         <li class="<?php echo e(Request::is( 'reports/allreports') ? 'active' : ''); ?>">
                             <a href="<?php echo e(URL::to( 'reports/account')); ?>" >
                                <p><?php echo trans('lang.account_transaction_report');?></p>
                            </a>
                        </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                </li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
               

				<li>
                    <a href="#">
                        <i class="ti-user"></i>
                        <p>Welcome, <?php echo e(Auth::user()->name); ?></p>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(URL::to( 'settings/profile')); ?>">
                        <i class="ti-settings"></i>
                        <p><?php echo trans('lang.profile_settings');?></p>
                    </a>
                </li>
				<li>
                    <a href="<?php echo e(URL::to( 'logout')); ?>">
                        <i class="ti-back-right"></i>
                        <p><?php echo trans('lang.logout');?></p>
                    </a>
                </li>
            </ul>

        </div>
    </div>
</nav>

        <?php echo $__env->yieldContent('content'); ?>
<footer class="footer">
    <div class="container-fluid">
        
        <div class="copyright pull-right">
            © 2017, made with <i class="fa fa-heart heart"></i> by <span class="company"></span></a>
        </div>
    </div>
</footer>
</div>

    
</body>
</html>
<script>
$(document).ready(function() {
$.ajax({
        type: "GET",
        url: "<?php echo e(url('settings/getapplication')); ?>",
        dataType: "json",
        data: "{}",
        success: function (html) {
			var objs = html.data;
			$(".company").html(objs[0].company);
			$("#city").val(objs[0].city);
			$("#currency").val(objs[0].currency);
			$("#phone").val(objs[0].phone);
			$("#address").val(objs[0].address);
            $("#locale").attr(objs[0].languages);
			$("#website").val(objs[0].website);
			$(".logoimg").attr("src",html.logo);

        },
    });
});	
</script>
