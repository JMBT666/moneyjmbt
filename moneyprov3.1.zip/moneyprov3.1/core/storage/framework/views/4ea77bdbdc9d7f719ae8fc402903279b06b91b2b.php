<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">
			<div class="card col-lg-12">
					<div class="header">
						<div class="row">
							<div class="col-lg-12">
							<h4 class="title">Application Setting</h4>
							</div>
						</div>
                    </div>
					<hr>
					<div class="row">
					<div id="message" style="display:none" class="alert alert-danger">All field required</div>
					<div id="message2" style="display:none" class="alert alert-success">Data has been updated sucessfully</div>
						<form action=""  name="formsetting">
						<div class="col-lg-6">
								<div class="form-group">
								  <label>Company Name</label>
								  <input type="text" class="form-control" name="company"  id="company" placeholder="Company Name" data-validation="required">
								</div>
								<div class="form-group">
								  <label>City</label>
								  <input type="text" class="form-control" name="city"  id="city" placeholder="City" data-validation="required">
								</div>
								<div class="form-group">
								  <label>Currency</label>
								  <input type="text" class="form-control" name="currency"  id="currency" placeholder="Currency" data-validation="required">
								</div>
						</div>
						<div class="col-lg-6">
								<div class="form-group">
								  <label>Website</label>
								  <input type="text" class="form-control" name="website"  id="website" placeholder="Website" data-validation="required">
								</div>
								<div class="form-group">
								  <label>Phone</label>
								  <input type="text" class="form-control" name="phone"  id="phone" placeholder="Phone" data-validation="required">
								</div>
								<div class="form-group">
								  <label>Address</label>
								  <input type="text" class="form-control" name="address"  id="address" placeholder="Address" data-validation="required">
								</div>
						</div>
						<div class="col-lg-8">
								<div class="form-group">
								  <label>Logo</label>
								  <input type="file" class="form-control" name="logo"  id="logo" placeholder="Logo" required>
								</div>
						</div>
						<div class="col-lg-4">
								<img id="logoimg" src="" style="width:257px;"/>
						</div>
						<div class="col-lg-6">
							<button type="button" class="btn btn-fill btn-info" id="save">Save Setting</button>
						</div>
						</form>
					</div>
			</div>
		</div>	
	</div>
</div>	

<script>
$(document).ready(function() {
	$.ajaxSetup({
       headers: {
           'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
       }
	});
    $.ajax({
        type: "GET",
        url: "<?php echo e(url('settings/getapplication')); ?>",
        dataType: "json",
        data: "{}",
        success: function (html) {
			var objs = html.data;
			$("#company").val(objs[0].company);
			$("#city").val(objs[0].city);
			$("#currency").val(objs[0].currency);
			$("#phone").val(objs[0].phone);
			$("#address").val(objs[0].address);
			$("#website").val(objs[0].website);
			$("#logoimg").attr("src",'../upload/'+objs[0].logo);

        },
    });
});	

$("#save").click(function(){

		var form = new FormData();
		var name=$("#name").val();
		var company=$("#company").val();
		var city=$("#city").val();
		var currency=$("#currency").val();
		var address=$("#address").val();
		var phone=$("#phone").val();
		var website=$("#website").val();
		var logo  = $('#logo')[0].files[0];
		
		
		form.append('company', company);
		form.append('city', city);
		form.append('currency', currency);
		form.append('address', address);
		form.append('website', website);
		form.append('phone', phone);
		form.append('logo', logo);
		if(company =='' || city =='' || currency =='' || address =='' || city =='' ){
			$("#message").css({'display':"block"});
			return false;
		}
		
		$.ajax({
			type: "POST",
            url: "<?php echo e(url('settings/saveapplication')); ?>",
            data: form,
			contentType: 'multipart/form-data',
			processData: false,
            contentType: false,
            success: function(data) {				
				$("#message2").css({'display':"block"});
				window.setTimeout(function(){location.reload()},2000)
            }
		});

});
	
</script>
<?php $__env->stopSection(); ?>		
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>