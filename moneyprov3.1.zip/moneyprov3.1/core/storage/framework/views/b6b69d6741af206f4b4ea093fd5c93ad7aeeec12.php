        
<!DOCTYPE html>
<html id="locale" lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title class="company"></title>

	  <!-- Bootstrap core CSS     -->
    <!--<link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" />-->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('css/bootstrap-datepicker.css')); ?>" rel="stylesheet">
    
    <!--  Paper Dashboard core CSS    -->

    <link href="<?php echo e(asset('css/paper-dashboard.css')); ?>" rel="stylesheet"/>
	
	<!--  Datatables    -->
	<link href="<?php echo e(asset('plugin/datatables/css/dataTables.bootstrap.css')); ?>" rel="stylesheet"/>

    <!--  Fonts and icons     -->
    <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Muli:400,300' rel='stylesheet' type='text/css'>
    <link href="<?php echo e(asset('css/themify-icons.css')); ?>"  rel="stylesheet">
    <link href="<?php echo e(asset('css/select2.min.css')); ?>"  rel="stylesheet">
	<link href="<?php echo e(asset('plugin/datatables/css/buttons.dataTables.min.css')); ?>"  rel="stylesheet">
	<link href="<?php echo e(asset('plugin/datatables/css/buttons.bootstrap.min.css')); ?>"  rel="stylesheet">
	<link href="<?php echo e(asset('plugin/morris/morris.css')); ?>"  rel="stylesheet">
	<link href="<?php echo e(asset('plugin/fullcalendar2/main.css')); ?>"  rel="stylesheet">

	<!-- Scripts -->

    <!--<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>-->
    <!--<script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
	<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/fullcalendar/lib/moment.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/fullcalendar/fullcalendar.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/datatables/js/jquery.dataTables.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/datatables/js/dataTables.bootstrap.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/datatables/js/dataTables.buttons.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/datatables/js/buttons.html5.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/datatables/js/buttons.print.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/datatables/js/buttons.bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/datatables/js/pdfmake.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/datatables/js/vfs_fonts.js')); ?>"></script>-->
     
     <!-- Script -->
    <script src="<?php echo e(asset('js/jquery-3.5.1.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap-datepicker.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <!--<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.min.js"></script>-->
    <script src="<?php echo e(asset('plugin/datatables/js/datatables.min.js')); ?>"></script>
    

    <script src="<?php echo e(asset('plugin/jqueryvalidation/jquery.validate.js')); ?>"></script>
    <script src="<?php echo e(asset('plugin/jqueryvalidation/additional-methods.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/chartjs/Chart.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/morris/morris.min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/jscolor/jscolor.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/morris/raphael-min.js')); ?>"></script>
	<script src="<?php echo e(asset('plugin/chartjs/Chart.PieceLabel.js')); ?>"></script>
    <script src="<?php echo e(asset('plugin/moment/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugin/fullcalendar2/main.min.js')); ?>"></script>

    <script>
        var company     = "<?php echo e($data->company); ?>";
        var currency    = "<?php echo e($data->currency); ?>";
        var language    = "<?php echo e($data->languages); ?>";
        var website     = "<?php echo e($data->website); ?>";
        var phone       = "<?php echo e($data->phone); ?>";
        var city        = "<?php echo e($data->city); ?>";
        var logo        = "<?php echo e(url('/upload/').'/'.$data->logo); ?>";
        var address     = "<?php echo e($data->address); ?>";
        var dateformat  = "<?php echo e($data->dateformat); ?>";

        //lang for datatables
        var overall             = "<?php echo e(trans('lang.overall')); ?>";
        var demptyTable         = "<?php echo e(trans('lang.demptyTable')); ?>";
        var dshowing            = "<?php echo e(trans('lang.dshowing')); ?>";
        var dto                 = "<?php echo e(trans('lang.dto')); ?>";
        var dof                 = "<?php echo e(trans('lang.dof')); ?>";
        var dentries            = "<?php echo e(trans('lang.dentries')); ?>";
        var dinfoEmpty          = "<?php echo e(trans('lang.dinfoEmpty')); ?>";
        var dfilter             = "<?php echo e(trans('lang.dfilter')); ?>";
        var total               = "<?php echo e(trans('lang.total')); ?>";
        var dshow               = "<?php echo e(trans('lang.dshow')); ?>";
        var dloadingRecords     = "<?php echo e(trans('lang.dloadingRecords')); ?>";
        var dprocessing         = "<?php echo e(trans('lang.dprocessing')); ?>";
        var dsearch             = "<?php echo e(trans('lang.dsearch')); ?>";
        var dzeroRecords        = "<?php echo e(trans('lang.dzeroRecords')); ?>";
        var dlast               = "<?php echo e(trans('lang.dlast')); ?>";
        var dnext               = "<?php echo e(trans('lang.dnext')); ?>";
        var dprevious           = "<?php echo e(trans('lang.dprevious')); ?>";
    </script>

    <script>
    $(document).ready(function() {

        $.ajaxSetup({
           headers: {
               'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
           }
        });

        $("body").tooltip({ selector: '[data-toggle=tooltip]' });
        $(".company").html(company);
        $("#city").val(city);
        $(".currency").val(currency);
        $(".currency").html(currency);
        $("#phone").val(phone);
        $("#address").val(address);    
        $("#locale").attr(language);  
        $("#website").val(website);
       });
    </script>
</head>
<body>
 
        
<div class="sidebar">	
<div class=" sidebar-wrapper">
    <div class="logo">
                <img class="logoimg" src="<?php echo e(url('/upload/').'/'.$data->logo); ?>" style="width:200px"/>
        </a>
    </div>
    <ul class="nav">
			
            <li class="<?php echo e(Request::is( 'home') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'home')); ?>" >
                    <i class="ti-panel"></i>
					<?php echo trans('lang.dashboard');?>
                </a>
            </li>
			<?php if(Auth::check()): ?>
				<?php if(Auth::user()->isrole('2')): ?>
			 <li class="<?php echo e(Request::is( 'transaction') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'transaction')); ?>" >
                    <i class="ti-direction-alt"></i>
					<?php echo trans('lang.transactions');?>
                </a>
            </li>
				<?php endif; ?>
			<?php endif; ?>
			<?php if(Auth::check()): ?>
				<?php if(Auth::user()->isrole('3')): ?>
			 <li class="<?php echo e(Request::is( 'income') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'income')); ?>" >
                    <i class="ti-stats-up"></i>
					<?php echo trans('lang.income');?>
                </a>
            </li>
				<?php endif; ?>
			<?php endif; ?>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('19')): ?>
             <li class="<?php echo e(Request::is( 'upcomingincome') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'upcomingincome')); ?>" >
                    <i class="ti-angle-double-up"></i>
                    <?php echo trans('lang.upcomingincome');?>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
			<?php if(Auth::check()): ?>
				<?php if(Auth::user()->isrole('4')): ?>
			 <li class="<?php echo e(Request::is( 'expense') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'expense')); ?>" >
                    <i class="ti-stats-down"></i>
					<?php echo trans('lang.expense');?>
                </a>
            </li>
				<?php endif; ?>
			<?php endif; ?>
             <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('20')): ?>
             <li class="<?php echo e(Request::is( 'upcomingexpense') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'upcomingexpense')); ?>" >
                    <i class="ti-angle-double-down"></i>
                    <?php echo trans('lang.upcomingexpense');?>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
			<?php if(Auth::check()): ?>
				<?php if(Auth::user()->isrole('5')): ?>
			 <li class="<?php echo e(Request::is( 'account') || Request::is('account/detail*') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'account')); ?>" >
                    <i class="ti-wallet"></i>
					<?php echo trans('lang.accounts');?>
                </a>
            </li>
				<?php endif; ?>
			<?php endif; ?>
			<?php if(Auth::check()): ?>
				<?php if(Auth::user()->isrole('6')): ?>
			 <li class="<?php echo e(Request::is( 'budget') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'budget')); ?>" >
                    <i class="ti-package"></i>
					<?php echo trans('lang.track_budget');?> 
                </a>
            </li>
				<?php endif; ?>
			<?php endif; ?>
			<?php if(Auth::check()): ?>
				<?php if(Auth::user()->isrole('7')): ?>
			 <li class="<?php echo e(Request::is( 'goals') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'goals')); ?>" >
                    <i class="ti-cup"></i>
					<?php echo trans('lang.set_goals');?>
                </a>
            </li>
				<?php endif; ?>
			<?php endif; ?>
			<?php if(Auth::check()): ?>
				<?php if(Auth::user()->isrole('8')): ?>
			<li class="<?php echo e(Request::is( 'calendar') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'calendar')); ?>" >
                    <i class="ti-calendar"></i>
					<?php echo trans('lang.calendar');?>
                </a>
            </li>
				<?php endif; ?>
			<?php endif; ?>
			
			 <li class="<?php echo e(Request::is( 'reports/allreports') || Request::is('reports/income') || Request::is('reports/expense') || Request::is('reports/incomevsexpense') || Request::is('reports/upcomingincome') || Request::is('reports/incomemonth') || Request::is('reports/expensemonth') || Request::is('reports/account') || Request::is('reports/upcomingexpense') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'reports/allreports')); ?>" >
                    <i class="ti-pie-chart"></i>
					<?php echo trans('lang.report_menu');?>
                </a>
            </li>
				
			 <li>
                 <a data-toggle="collapse" href="#category" class="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? '' : 'collapsed'); ?>" aria-expanded="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? 'true' : 'false'); ?>">
                    <i class="ti-flag-alt"></i>
                    <?php echo trans('lang.category');?><b class="caret"></b>
                </a>
				<div class="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? 'collapse in' : 'collapse'); ?>" id="category" aria-expanded="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? 'true' : 'false'); ?>" style="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? '' : 'height: 0px;'); ?>">
                    <ul class="nav">
						<?php if(Auth::check()): ?>
							<?php if(Auth::user()->isrole('9')): ?>
                          <li class="<?php echo e(Request::is( 'incomecategory') ? 'active' : ''); ?>">
                            <a href="<?php echo e(URL::to( 'incomecategory')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.income_category');?></span>
                            </a>
                        </li>
							<?php endif; ?>
						<?php endif; ?>
						<?php if(Auth::check()): ?>
							<?php if(Auth::user()->isrole('10')): ?>
						<li class="<?php echo e(Request::is( 'expensecategory') ? 'active' : ''); ?>">
                           <a href="<?php echo e(URL::to( 'expensecategory')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.expense_category');?></span>
                            </a>
                        </li>
							<?php endif; ?>
						<?php endif; ?>
                    </ul>
                </div>
            </li>


			 <li>
                 <a data-toggle="collapse" href="#settings" class="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? '' : 'collapsed'); ?>" aria-expanded="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? 'true' : 'false'); ?>">
                    <i class="ti-settings"></i>
                    <?php echo trans('lang.setting_menu');?><b class="caret"></b>
                </a>
				<div class="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? 'collapse in' : 'collapse'); ?>" id="settings" aria-expanded="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? 'true' : 'false'); ?>" style="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? '' : 'height: 0px;'); ?>">
                    <ul class="nav">
                        <li class="<?php echo e(Request::is( 'settings/profile') ? 'active' : ''); ?>">
                            <a href="<?php echo e(URL::to( 'settings/profile')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.profile_settings');?></span>
                            </a>
                        </li>
						<?php if(Auth::check()): ?>
							<?php if(Auth::user()->isrole('17')): ?>
						<li class="<?php echo e(Request::is( 'settings/allusers') ? 'active' : ''); ?>">
                            <a href="<?php echo e(URL::to( 'settings/allusers')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.user_role');?></span>
                            </a>
                        </li>
							<?php endif; ?>
						<?php endif; ?>
						<?php if(Auth::check()): ?>
							<?php if(Auth::user()->isrole('18')): ?>
                           <li class="<?php echo e(Request::is( 'settings/application') ? 'active' : ''); ?>">
                            <a href="<?php echo e(URL::to( 'settings/application')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.application_setting');?></span>
                            </a>
                        </li>
							<?php endif; ?>
						<?php endif; ?>	
                    </ul>
                </div>
    </ul>
</div>
</div>
<div class="main-panel">
<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="d-none navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span> 
            </button>
            <a class="navbar-brand" href="#"><p class="company mb-0"></p></a>
        </div>

        <!--responsive-->
        <div class="collapse" id="myNavbar">
        <ul class="nav">
            
            <li  class="<?php echo e(Request::is( 'home') ? 'active' : ''); ?>">
                <a  href="<?php echo e(URL::to( 'home')); ?>" >
                    <?php echo trans('lang.dashboard');?>
                </a>
            </li>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('2')): ?>
             <li class="<?php echo e(Request::is( 'transaction') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'transaction')); ?>" >
                   <?php echo trans('lang.transactions');?>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('3')): ?>
             <li class="<?php echo e(Request::is( 'income') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'income')); ?>" >
                    <?php echo trans('lang.income');?>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('19')): ?>
             <li class="<?php echo e(Request::is( 'upcomingincome') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'upcomingincome')); ?>" >
                    <?php echo trans('lang.upcomingincome');?>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('4')): ?>
             <li class="<?php echo e(Request::is( 'expense') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'expense')); ?>" >
                    <?php echo trans('lang.expense');?>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
             <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('20')): ?>
             <li class="<?php echo e(Request::is( 'upcomingexpense') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'upcomingexpense')); ?>" >
                    <?php echo trans('lang.upcomingexpense');?>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('5')): ?>
             <li class="<?php echo e(Request::is( 'account') || Request::is( 'account/detail*') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'account')); ?>" >
                    <?php echo trans('lang.accounts');?>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('6')): ?>
             <li class="<?php echo e(Request::is( 'budget') ? 'active' : ''); ?>">
                 <a href="<?php echo e(URL::to( 'budget')); ?>" >
                    <?php echo trans('lang.track_budget');?>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('7')): ?>
             <li class="<?php echo e(Request::is( 'goals') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'goals')); ?>" >
                    <?php echo trans('lang.set_goals');?>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->isrole('8')): ?>
            <li class="<?php echo e(Request::is( 'calendar') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'calendar')); ?>" >
                    <?php echo trans('lang.calendar');?>
                </a>
            </li>
                <?php endif; ?>
            <?php endif; ?>
            
             <li class="<?php echo e(Request::is( 'reports/allreports') || Request::is('reports/income') || Request::is('reports/expense') || Request::is('reports/incomevsexpense') || Request::is('reports/upcomingincome') || Request::is('reports/incomemonth') || Request::is('reports/expensemonth') || Request::is('reports/account') || Request::is('reports/upcomingexpense') ? 'active' : ''); ?>">
                <a href="<?php echo e(URL::to( 'reports/allreports')); ?>" >
                    <?php echo trans('lang.report_menu');?>
                </a>
            </li>
                
             <li>
                 <a data-toggle="collapse" href="#categorys" class="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? '' : 'collapsed'); ?>" aria-expanded="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? 'true' : 'false'); ?>">
                    <p><?php echo trans('lang.category');?><b class="caret"></b></p>
                </a>
                <div class="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? 'collapse in' : 'collapse'); ?>" id="categorys" aria-expanded="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? 'true' : 'false'); ?>" style="<?php echo e(Request::is( 'incomecategory') || Request::is( 'expensecategory') ? '' : 'height: 0px;'); ?>">
                    <ul class="nav">
                        <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->isrole('9')): ?>
                          <li class="<?php echo e(Request::is( 'incomecategory') ? 'active' : ''); ?>">
                            <a href="<?php echo e(URL::to( 'incomecategory')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.income_category');?></span>
                            </a>
                        </li>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->isrole('10')): ?>
                        <li class="<?php echo e(Request::is( 'expensecategory') ? 'active' : ''); ?>">
                           <a href="<?php echo e(URL::to( 'expensecategory')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.expense_category');?></span>
                            </a>
                        </li>
                            <?php endif; ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </li>


             <li>
                 <a data-toggle="collapse" href="#settingss" class="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? '' : 'collapsed'); ?>" aria-expanded="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? 'true' : 'false'); ?>">
                    <p><?php echo trans('lang.setting_menu');?><b class="caret"></b></p>
                </a>
                <div class="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? 'collapse in' : 'collapse'); ?>" id="settingss" aria-expanded="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? 'true' : 'false'); ?>" style="<?php echo e(Request::is( 'settings/profile') || Request::is( 'settings/allusers') || Request::is( 'settings/application') ? '' : 'height: 0px;'); ?>">
                    <ul class="nav">
                        <li class="<?php echo e(Request::is( 'settings/profile') ? 'active' : ''); ?>">
                            <a href="<?php echo e(URL::to( 'settings/profile')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.profile_settings');?></span>
                            </a>
                        </li>
                        <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->isrole('17')): ?>
                        <li class="<?php echo e(Request::is( 'settings/allusers') ? 'active' : ''); ?>">
                            <a href="<?php echo e(URL::to( 'settings/allusers')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.user_role');?></span>
                            </a>
                        </li>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->isrole('18')): ?>
                           <li class="<?php echo e(Request::is( 'settings/application') ? 'active' : ''); ?>">
                            <a href="<?php echo e(URL::to( 'settings/application')); ?>" >
                                <span class="sidebar-mini"><i class="ti-angle-right"></i></span>
                                <span class="sidebar-normal"><?php echo trans('lang.application_setting');?></span>
                            </a>
                        </li>
                            <?php endif; ?>
                        <?php endif; ?>  
                    </ul>
                </div>
            </ul>
    </div>
        <!--end responsive-->

        <div class="d-none d-md-block ">

            <ul class="right-nav mb-0">
				<li>
                    <a href="#">
                        <i class="ti-user"></i>
                        Welcome, <?php echo e(Auth::user()->name); ?>

                    </a>
                </li>
                <li>
                    <a href="<?php echo e(URL::to( 'settings/profile')); ?>">
                        <i class="ti-settings"></i>
                        <?php echo trans('lang.profile_settings');?>
                    </a>
                </li>
				<li>
                    <a href="<?php echo e(URL::to( 'logout')); ?>">
                        <i class="ti-back-right"></i>
                        <?php echo trans('lang.logout');?>
                    </a>
                </li>
            </ul>

        </div>
    </div>
</nav>

        <?php echo $__env->yieldContent('content'); ?>
<footer class="footer">
    <div class="container-fluid">
        
        <div class="copyright pull-right">
            © 2021, made with <i class="fa fa-heart heart"></i> by <span class="company"></span></a>
        </div>
    </div>
</footer>
</div>

</body>
</html>

