<?php $__env->startSection('content'); ?>

<div class="content">
    <div class="container-fluid">
        <div class="row">
			<div class="card col-lg-12">
					<div class="header">
						<div class="row">
							<div class="col-lg-12">
							<h4 class="title">Profile Setting</h4>
							</div>
						</div>
                    </div>
					<hr>
					<div class="row">
					<div id="message" style="display:none" class="alert alert-danger">All field required</div>
					<div id="message2" style="display:none" class="alert alert-success">Data has been updated sucessfully</div>
						<form action=""  name="formsetting">
						<div class="col-lg-6">
								<div class="form-group">
								  <label>Full Name</label>
								  <input type="text" class="form-control" name="name"  id="name" placeholder="Full Name" data-validation="required">
								</div>
								<div class="form-group">
								  <label>Phone</label>
								  <input type="text" class="form-control" name="phone"  id="phone" placeholder="Phone Number" data-validation="required">
								</div>
						</div>
						<div class="col-lg-6">
								<div class="form-group">
								  <label>Email</label>
								  <input type="email" class="form-control" name="email"  id="email" placeholder="Email" data-validation="required">
								</div>
								<div class="form-group">
								  <label>Password</label>
								  <input type="password" class="form-control" name="password"  id="password" placeholder="Password" >
								  <p class="text-help">Note: if you populate this field, password will be changed.</p>
								</div>	
									
						</div>

						<div class="col-lg-6">
							<button type="button" class="btn btn-fill btn-info" id="save">Save Profile</button>
						</div>
						</form>
					</div>
			</div>
		</div>	
	</div>
</div>	

<script>
$(document).ready(function() {
	$.ajaxSetup({
       headers: {
           'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
       }
	});
    $.ajax({
        type: "GET",
        url: "<?php echo e(url('settings/getprofile')); ?>",
        dataType: "json",
        data: "{}",
        success: function (html) {
			var objs = html.data;
			$("#name").val(objs[0].name);
			$("#email").val(objs[0].email);
			$("#phone").val(objs[0].phone);

        },
    });
});	

$("#save").click(function(){

		var name=$("#name").val();
		var email=$("#email").val();
		var phone=$("#phone").val();
		var password=$("#password").val();
		
		
		
		if(name =='' || email ==''){
			$("#message").css({'display':"block"});
			return false;
		}
		
		$.ajax({
			type: "POST",
            url: "<?php echo e(url('settings/saveprofile')); ?>",
            data: {email:email,name:name,password:password,phone:phone},
            success: function(data) {				
				$("#message2").css({'display':"block"});
				window.setTimeout(function(){location.reload()},2000)
            }
		});

});
	
</script>
<?php $__env->stopSection(); ?>		
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>