<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BudgetModel extends Model
{
    //
}
