<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'E-Posta Adresiniz veya Kullanici Adiniz Yanlis.',
    'throttle' => 'UYARI ! Cok Fazla Giris Denemesi, Lutfen 2 Dakika Sonra Tekrar Deneyin.',

];
