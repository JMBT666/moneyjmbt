<?php
return [
	//Settings Module
	'application_setting' => 'Pengaturan Aplikasi',
    'company_name' => 'Perusahaan',
    'website' => 'Website',
    'city' => 'Kota',
    'phone' => 'Telepon',
    'currency' => 'Mata Uang',
    'address' => 'Alamat',
    'save_settings' =>'Simpan Pengaturan',
    //User Role
    'total_user' =>'Total Pengguna',
    'active_user' =>'Pengguna Aktif',
    'inactive_user' =>'Pengguna Tidak Aktif',
    'user_list' => 'List Pengguna',
    'add_new_user' => 'Tambah Pengguna'


];